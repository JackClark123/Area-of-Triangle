package MapGeneration;
public enum Tiles {
	
	FLOOR, WALL, PLAYER;

}
